/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package extractionstep2;
import java.io.*;
import java.nio.channels.*;
import java.util.*;
import java.io.File;
import java.io.IOException;


public class ExtractionStep2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //Input for user defined SIP folder name
        System.out.print("Enter Your Main Archive Folder Name: ");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
                
        String myDirectory = br.readLine();
        
        
        
        
        
        
        
        
        
        
        
    }
}
