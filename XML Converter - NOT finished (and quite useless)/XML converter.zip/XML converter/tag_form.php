
<HTML>
<HEAD><Title>XML Tag Coverter</Title></HEAD>
<BODY>

<?php include("config.php"); ?>

<div style="margin-left:auto; margin-right:auto; width: 700px; border-style: solid; border-width: 2px; padding:5px;">
<H2>IME - DSpace Ingestor v.0.7</H2>
<p>Enter the tags that you want to convert</p>
<form action="config.php" method="post">
XML File Location: <input type="text" name="xml_locat" />
Example: "C:/data","/usr/share/webapps/xml_converter/in"
</form>
<form action="get_input.php" method="post">
<input type="submit"/>
Tag 1: <input type="text" name="tag_1_in" /> converted to <input type="text" name="tag_1_out" />
Tag 2: <input type="text" name="tag_2_in" /> converted to <input type="text" name="tag_2_out" />
Tag 3: <input type="text" name="tag_3_in" /> converted to <input type="text" name="tag_3_out" />
Tag 4: <input type="text" name="tag_4_in" /> converted to <input type="text" name="tag_4_out" />
Tag 5: <input type="text" name="tag_5_in" /> converted to <input type="text" name="tag_5_out" />
Tag 6: <input type="text" name="tag_6_in" /> converted to <input type="text" name="tag_6_out" />
Tag 7: <input type="text" name="tag_7_in" /> converted to <input type="text" name="tag_7_out" />
Tag 8: <input type="text" name="tag_8_in" /> converted to <input type="text" name="tag_8_out" />
Tag 9: <input type="text" name="tag_9_in" /> converted to <input type="text" name="tag_9_out" />
Tag 10: <input type="text" name="tag_10_in" /> converted to <input type="text" name="tag_10_out" />
Tag 11: <input type="text" name="tag_11_in" /> converted to <input type="text" name="tag_11_out" />
Tag 12: <input type="text" name="tag_12_in" /> converted to <input type="text" name="tag_12_out" />
Tag 13: <input type="text" name="tag_13_in" /> converted to <input type="text" name="tag_13_out" />
Tag 14: <input type="text" name="tag_14_in" /> converted to <input type="text" name="tag_14_out" />
Tag 15: <input type="text" name="tag_15_in" /> converted to <input type="text" name="tag_15_out" />
Tag 16: <input type="text" name="tag_16_in" /> converted to <input type="text" name="tag_16_out" />
Tag 17: <input type="text" name="tag_17_in" /> converted to <input type="text" name="tag_17_out" />
Tag 18: <input type="text" name="tag_18_in" /> converted to <input type="text" name="tag_18_out" />
Tag 19: <input type="text" name="tag_19_in" /> converted to <input type="text" name="tag_19_out" />
Tag 20: <input type="text" name="tag_20_in" /> converted to <input type="text" name="tag_20_out" />
Tag 21: <input type="text" name="tag_21_in" /> converted to <input type="text" name="tag_21_out" />
Tag 22: <input type="text" name="tag_22_in" /> converted to <input type="text" name="tag_22_out" />
Tag 23: <input type="text" name="tag_23_in" /> converted to <input type="text" name="tag_23_out" />
Tag 24: <input type="text" name="tag_24_in" /> converted to <input type="text" name="tag_24_out" />
Tag 25: <input type="text" name="tag_25_in" /> converted to <input type="text" name="tag_25_out" />
</form>
<p><a href="process_titles.php">Process Another set of Titles</a></p>

<a href="index.php">Back</a>

</div>
</BODY>
</HTML>	



}
