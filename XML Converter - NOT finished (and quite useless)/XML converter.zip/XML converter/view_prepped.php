<?php

// Will display all items prepped

include_once("config.php");

?>
<iframe src="<?php echo $DISPLAY_DIR ?>" width="90%" height="400"></iframe><br></br>
<a href="index.php">Back</a>