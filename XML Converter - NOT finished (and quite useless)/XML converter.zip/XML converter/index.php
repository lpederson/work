<HTML>
<HEAD><Title>XML Tag Coverter</Title></HEAD>
<BODY>

<?php include("config.php"); ?>

<div style="margin-left:auto; margin-right:auto; width: 700px; border-style: solid; border-width: 2px; padding:5px;">
<H2>IME - DSpace Ingestor v.0.7</H2>
<p>Application for changing XML to DSpace acceptable tags</p>
<p><a href="tag_form.php">Change tag to DC tag</a></p>
<p><a href="<?php echo $TITLES_DONE ?>">View Finished Titles (CSV)</a></p>
<p><a href="view_prepped.php">View Prepped Data</a></p>
</p> 


</div>
</BODY>
</HTML>