

DSpace Ingestor v.0.7  -by Tim Ribaric tim@elibtronic.ca

The DSpace Ingestor

Simply untar this and place it in a spot that is visible to both the IAScraper and your DSpace instance.
The instructions given are for 'nix based systems but it should be easy enough to change for Windows environments.
*Note* This software won't complete the last step of the process but will explain what you need to type in for it to happen.
For more information about how DSpace ingests items in bulk please check the DSpace documentation: http://www.dspace.org/1_5_2Documentation/ch09.html#N13795 (for version 1.5)