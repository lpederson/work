
IA Scraper v0.7 -by Tim Ribaric tim@elibtronic.ca

The Internet Archive Scraper

Simply untar the software edit config.php and you should be ready to go
You'll need CURL installed and working in your php config for this to work

The main page will suggest what you should add to your crontab to automate the RSS scraping

The downloading takes a bit so be patient (items can be up to 25megs), it is best to automate the RSS scrape and use that.