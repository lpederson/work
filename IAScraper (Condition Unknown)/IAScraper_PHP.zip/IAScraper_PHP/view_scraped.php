<?php

// view_scraped.php
// Will display all items scrapped and listed in the D

include_once("config.php");

?>
<iframe src="<?php echo $DISPLAY_DIR ?>" width="90%" height="400"></iframe><br></br>
<a href="index.php">Back</a>