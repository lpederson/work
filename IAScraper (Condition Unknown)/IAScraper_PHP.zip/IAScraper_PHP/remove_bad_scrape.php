<?php
// Removes all empty folders containing an empty PDF, _meta.xml, or _dc.xml

include ('config.php');

RmFoldersWithEmptyFiles($DATA_DIR);


function RmFoldersWithEmptyFiles($main_dir) {
    clearstatcache();
	$dirs = scandir($main_dir);
        foreach($dirs as $dir)  {
            if ($dir === '.' || $dir === '..') {
                continue; }
            $files=scandir($main_dir."/".$dir);
                foreach ($files as $file)  {
                if ($file === '.' || $file === '..') {
                    continue;
                } else {
						$file = trim($file);
						if(filesize("/".$main_dir."/".$dir."/".$file) == 0) // || !file_exists($file))
						{
							echo $file . " has a file size of 0\n";
							echo $dir . " directory contains ".$file." and is being deleted!\n";
							recursive_remove_directory("/".$main_dir."/".$dir."/");
						}
						break;
                    }
                }
		}   
} 

 // ------------ lixlpixel recursive PHP functions -------------
 // recursive_remove_directory( directory to delete, empty )
 // expects path to directory and optional TRUE / FALSE to empty
 // of course PHP has to have the rights to delete the directory
 // you specify and all files and folders inside the directory
 // ------------------------------------------------------------

 // to use this function to totally remove a directory, write:
 // recursive_remove_directory('path/to/directory/to/delete');

 // to use this function to empty a directory, write:
 // recursive_remove_directory('path/to/full_directory',TRUE);

 function recursive_remove_directory($directory, $empty=FALSE)
 {
     // if the path has a slash at the end we remove it here
     if(substr($directory,-1) == '/')
     {
         $directory = substr($directory,0,-1);
     }
  
     // if the path is not valid or is not a directory ...
     if(!file_exists($directory) || !is_dir($directory))
     {
         // ... we return false and exit the function
		 echo "Not a directory!\n";
         return FALSE;
  
     // ... if the path is not readable
     }elseif(!is_readable($directory))
     {
         // ... we return false and exit the function
         return FALSE;
 
     // ... else if the path is readable
     }else{
  
         // we open the directory
         $handle = opendir($directory);
  
         // and scan through the items inside
         while (FALSE !== ($item = readdir($handle)))
         {
             // if the filepointer is not the current directory
             // or the parent directory
             if($item != '.' && $item != '..')
             {
                 // we build the new path to delete
                 $path = $directory.'/'.$item;
  
                 // if the new path is a directory
                 if(is_dir($path)) 
                 {
                     // we call this function with the new path
                     recursive_remove_directory($path);
  
                 // if the new path is a file
                 }else{
                     // we remove the file
                     unlink($path);
                 }
             }
         }
         // close the directory
         closedir($handle);
  
         // if the option to empty is not set to true
         if($empty == FALSE)
         {
             // try to delete the now empty directory
             if(!rmdir($directory))
             {
                 // return false if not possible
                 return FALSE;
             }
         }
         // return success
         return TRUE;
     }
 }
 // ------------------------------------------------------------

 ?>